﻿using System;
using System.IO;
using System.Windows;

namespace DnD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public readonly string DirPath = AppDomain.CurrentDomain.BaseDirectory;

        private void lv_list_Drop(object sender, DragEventArgs e)
        {
            string[] file_pathes = (string[])e.Data.GetData(DataFormats.FileDrop);

            foreach (var path in file_pathes)
            {
                string new_path = DirPath+Path.GetFileName(path);

                File.Copy(path, new_path);

                lv_list.Items.Add(new FileObject(Path.GetFileName(path), new_path));
            }
        }

        private void lv_list_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (e.MouseDevice.LeftButton==System.Windows.Input.MouseButtonState.Pressed)
            {
                var file = lv_list.SelectedItem as FileObject;
                if(file!=null)
                DragDrop.DoDragDrop(this, new DataObject(DataFormats.FileDrop, new string[] { file.FullName }), DragDropEffects.Move);
                lv_list.Items.Remove(file);
            }
        }
    }

    class FileObject
    {
        public string Name { get; set; }

        public string FullName { get; set; }

        public FileObject(string name, string fullname)
        {
            Name = name;
            FullName = fullname;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
